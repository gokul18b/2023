var patientList = new Array();
(function init(){
  (function(){
    var studyList = new Array();
    (function(){
      var seriesList = new Array();
      (function(){
        var imageList = new Array();
        imageList.push('00000001.JPG');
        imageList.push('00000002.JPG');
        imageList.push('00000003.JPG');
        imageList.push('00000004.JPG');
        imageList.push('00000005.JPG');
        imageList.push('00000006.JPG');
        imageList.push('00000007.JPG');
        imageList.push('00000008.JPG');
        imageList.push('00000009.JPG');
        imageList.push('00000010.JPG');
        imageList.push('00000011.JPG');
        imageList.push('00000012.JPG');
        imageList.push('00000013.JPG');
        imageList.push('00000014.JPG');
        imageList.push('00000015.JPG');
        imageList.push('00000016.JPG');
        imageList.push('00000017.JPG');
        imageList.push('00000018.JPG');
        imageList.push('00000019.JPG');
      seriesList.push(new Series('US', '', '1', 0, imageList, 'SER00001'));
      })();
    studyList.push(new Study('20180517', '091728', 'USG GROWTH SCAN - TWINS', '1.2.840.113619.6.95.31.0.3.4.1.1501.13.1370609', '', '1896028', seriesList, 6, 'STD00001'));
    })();
  patientList.push(new Patient('NARMADHA S', '1146849', 'F', '19930820', studyList, 4));
  })();
})();
